//
// Programmer               : Rethabile Eric Siase
// Time taken to complete   : 1 days 
// Number of external help  : 0
// Complexity               : basic
// Purpose                  : Add or Subtract random numbers
//

// model class
class RandomModel {
  int randomNumber1;
  int randomNumber2;
  int result;
  RandomModel({required this.randomNumber1, required this.randomNumber2,required this.result});
}
